#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>
#define MAX_PROCESSES 1000
#define PORT 1500
#define BACKLOG 3
typedef struct {
    char name[256];  
    int pid;
    float user_time; 
    float kernel_time; 
} ProcessInfo;

int compare(const void *a, const void *b) {
    float total_a = ((ProcessInfo *)a)->user_time + ((ProcessInfo *)a)->kernel_time;
    float total_b = ((ProcessInfo *)b)->user_time + ((ProcessInfo *)b)->kernel_time;
    return (total_b - total_a); 
}

void get_stat(ProcessInfo processes[], int *count) {
    DIR *dir;
    struct dirent *entry;
    *count = 0;

    if ((dir = opendir("/proc")) == NULL) {
        perror("opendir");
        return;
    }
    while ((entry = readdir(dir)) != NULL) {
        // printf("%s\n" ,entry->d_name);
        if (!isdigit(*entry->d_name)) continue; 
        char path[256];
        snprintf(path, sizeof(path), "/proc/%s/stat", entry->d_name);
        
        int fd = open(path, O_RDONLY);
        if (fd < 0) {
            perror("open");
            continue;
        }

        char buffer[256];
        ssize_t bytes_read = read(fd, buffer, sizeof(buffer) - 1);
        if (bytes_read < 0) {
            perror("read");
            close(fd);
            continue;
        }
        buffer[bytes_read] = '\0'; 

        int pid, utime, stime;
        char name[256];
       sscanf(buffer, "%d (%[^)]) %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %d %d", 
       &pid, name, &utime, &stime);
        processes[*count].pid = pid;
        processes[*count].user_time = (float)utime;   
        processes[*count].kernel_time = (float)stime; 
        strncpy(processes[*count].name, name, sizeof(processes[*count].name));
        (*count)++;

        close(fd); 
    }
    closedir(dir);
}

void *handle_connection(void *socket_desc) {
    int newfd = *(int *)socket_desc;
    char buf[100];
    free(socket_desc); 
    recv(newfd, buf, sizeof(buf) - 1, 0);
    printf("Received to server: %s\n", buf);
    ProcessInfo processes[MAX_PROCESSES];
    int count;
    get_stat(processes, &count); 
    qsort(processes, count, sizeof(ProcessInfo), compare);
    char to_send[1000] = "Top 2 CPU consuming tasks:\n";
    for (int i = 0; i < count && i < 2; i++) {
        char line[256];
        snprintf(line, sizeof(line), "PID: %d, Name: %s, User Time: %.2f, Kernel Time: %.2f\n", 
                processes[i].pid, processes[i].name, processes[i].user_time, processes[i].kernel_time);
        strncat(to_send, line, sizeof(to_send) - strlen(to_send) - 1);
    } 
    send(newfd, to_send, strlen(to_send), 0);
    close(newfd); 
    return NULL;
}
int main(){
    int sockfd , *newfd;
    struct sockaddr_in my_addr, their_add;
    int sin_size;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("socket failed: %d\n", errno);
        return -1;
    }

    int opt = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(PORT);
    my_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    memset(&(my_addr.sin_zero), 0, sizeof(my_addr.sin_zero));
    if (bind(sockfd, (struct sockaddr*)&my_addr, sizeof(my_addr)) < 0) {
        printf("bind error: %d\n", errno);
        return -1;
    }
    listen(sockfd , BACKLOG);
    while(1){
        printf("hello\n");
        sin_size = sizeof(struct sockaddr_in);
        newfd = malloc(sizeof(int));
        *newfd = accept(sockfd, (struct sockaddr*)&their_add, &sin_size);
        if (*newfd == -1){
            printf("accept failed: %d\n", errno);
            free(newfd); 
        }
        else{
            printf("received successfully\n");
            handle_connection(newfd);
        }
    }

}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>  
#include<pthread.h>
#define DEST_IP "127.0.0.1"
#define DEST_PORT 1500
struct ClientData{
    int thread_id;
    struct sockaddr_in serv_addr;
};
void *client_thread(void *arg){
    struct ClientData* data = (struct ClientData*)arg;
    int sockfd , newfd;
    char buf[1000];
    char to_send[100] = "Send Top 2 CPU consuming tasks";
    sockfd = socket(AF_INET , SOCK_STREAM , 0);
    if (sockfd ==-1){
        printf("socket failed:%d" ,errno);
        return NULL;
    }
    if (connect(sockfd , (struct sockaddr*) & data->serv_addr, sizeof(struct sockaddr)) == 1){
        printf("CIient: Connect failed:%d" , errno);
        return NULL;
    }
    else{
        printf("Client: Connect successfull");
        send(sockfd , to_send , strlen(to_send) , 0);
        recv(sockfd , buf , 1000 , 0);
        if (recv < 0){
            printf("Message not received\n");
        }
        // printf("Thread\n %d" , data->thread_id);
        printf("Thread %d: Hello message sent\n , %s" , data->thread_id , buf);
    }
}
int main(int argc, char *argv[]){
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <number_of_clients>\n", argv[0]);
        return 1;
    }
    int n = atoi(argv[1]);
    struct sockaddr_in dest_addr;
    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(DEST_PORT);
    dest_addr.sin_addr.s_addr = inet_addr(DEST_IP);
    memset(&(dest_addr.sin_zero), 0, sizeof(dest_addr.sin_zero));
    struct ClientData thread_data[n];
    for (int i = 0; i < n; i++) {
        thread_data[i].serv_addr = dest_addr;
        thread_data[i].thread_id = i;
        client_thread(thread_data);
    }
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>
#include <dirent.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/select.h>

#define MAX_PROCESSES 1000
#define PORT 1500
#define BACKLOG 3
#define MAX_CLIENTS 200

typedef struct {
    char name[256];  
    int pid;
    float user_time; 
    float kernel_time; 
} ProcessInfo;

int compare(const void *a, const void *b) {
    float total_a = ((ProcessInfo *)a)->user_time + ((ProcessInfo *)a)->kernel_time;
    float total_b = ((ProcessInfo *)b)->user_time + ((ProcessInfo *)b)->kernel_time;
    return (total_b - total_a); 
}

void get_stat(ProcessInfo processes[], int *count) {
    DIR *dir;
    struct dirent *entry;
    *count = 0;

    if ((dir = opendir("/proc")) == NULL) {
        perror("opendir");
        return;
    }
    while ((entry = readdir(dir)) != NULL) {
        // printf("%s\n" ,entry->d_name);
        if (!isdigit(*entry->d_name)) continue; 
        char path[256];
        snprintf(path, sizeof(path), "/proc/%s/stat", entry->d_name);
        
        int fd = open(path, O_RDONLY);
        if (fd < 0) {
            perror("open");
            continue;
        }

        char buffer[256];
        ssize_t bytes_read = read(fd, buffer, sizeof(buffer) - 1);
        if (bytes_read < 0) {
            perror("read");
            close(fd);
            continue;
        }
        buffer[bytes_read] = '\0'; 

        int pid, utime, stime;
        char name[256];
       sscanf(buffer, "%d (%[^)]) %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %d %d", 
       &pid, name, &utime, &stime);
        processes[*count].pid = pid;
        processes[*count].user_time = (float)utime;   
        processes[*count].kernel_time = (float)stime; 
        strncpy(processes[*count].name, name, sizeof(processes[*count].name));
        (*count)++;

        close(fd); 
    }
    closedir(dir);
}

int main(){
    int sockfd, cl_fd, max_fd, sd, client_sockets[MAX_CLIENTS] = {0};
    char recv_buf[1024], send_buf[1024];
    struct sockaddr_in my_addr;
    socklen_t sock_len = sizeof(my_addr);
    fd_set read_mask;
    fd_set all_reads;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("socket failed: %d\n", errno);
        return -1;
    }

    int opt = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0){
        perror("Setsockopt failed");
        exit(EXIT_FAILURE);
    }

    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(PORT);
    my_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    memset(&(my_addr.sin_zero), 0, sizeof(my_addr.sin_zero));
    
    if (bind(sockfd, (struct sockaddr*)&my_addr, sizeof(my_addr)) < 0) {
        printf("bind error: %d\n", errno);
        return -1;
    }
    
    listen(sockfd, BACKLOG);

    FD_ZERO(&all_reads);
    FD_SET(sockfd, &all_reads);
    max_fd = sockfd;

    while(1){
        read_mask = all_reads;
        int rc = select(max_fd + 1, &read_mask, NULL, NULL, NULL);
        if (rc < 0 ){
            perror("select failed");
            exit(EXIT_FAILURE);
        }

        if (FD_ISSET(sockfd, &read_mask)){
            cl_fd = accept(sockfd, (struct sockaddr *)&my_addr, &sock_len);
            if (cl_fd < 0) {
                perror("accept failed.");
                continue;
            }
            if (cl_fd > max_fd) {
                max_fd = cl_fd;
            }

            FD_SET(cl_fd, &all_reads);
            printf("New connection found %d:\n", cl_fd);

            for (int i = 0; i < MAX_CLIENTS; i++) {
                if (client_sockets[i] == 0) {
                    client_sockets[i] = cl_fd;
                    break;
                }
            }
        }

        for(int i = 0; i < MAX_CLIENTS; i++){
            sd = client_sockets[i];
            if (FD_ISSET(sd, &read_mask)){
                memset(recv_buf, 0, sizeof(recv_buf));
                ssize_t rt = read(sd, recv_buf, sizeof(recv_buf));
                if (rt < 0){
                    printf("unable to read\n");
                } else if (rt == 0) {
                    printf("client closed, conn-fd: %d\n", sd);
                    FD_CLR(sd, &all_reads);
                    close(sd);
                    client_sockets[i] = 0; 
                    continue;
                }
                recv_buf[rt] = '\0'; 
                printf("Received to server: %s\n", recv_buf);
                
                ProcessInfo processes[MAX_PROCESSES];
                int count;
                get_stat(processes, &count); 
                qsort(processes, count, sizeof(ProcessInfo), compare);
                
                char to_send[1000] = "Top 2 CPU consuming tasks:\n";
                for (int i = 0; i < count && i < 2; i++) {
                    char line[256];
                    snprintf(line, sizeof(line), "PID: %d, Name: %s, User Time: %.2f, Kernel Time: %.2f\n", 
                            processes[i].pid, processes[i].name, processes[i].user_time, processes[i].kernel_time);
                    strncat(to_send, line, sizeof(to_send) - strlen(to_send) - 1);
                }

                if (send(sd, to_send, strlen(to_send), 0) < 0) {
                    perror("send failed");
                }
            }
        }
    }

    return 0;
}
